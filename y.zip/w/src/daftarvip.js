const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

-Rp. 10 > Acessar recursos ViP
-Rp. 20 > Recursos VIP + Insira o bot no seu grupo!

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/556993733829 ou digite *${prefix}owner*_

*NOTA*

*GRUPO DO BOT:*
_https://chat.whatsapp.com/J2ZGIuyEx1hAUmjjIqXZD5 `
}
exports.daftarvip = daftarvip
